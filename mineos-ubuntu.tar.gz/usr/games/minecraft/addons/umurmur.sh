#!/bin/bash

if [ "$(id -u)" != "0" ]; then
	echo "This script must be run as root" 1>&2
	exit 1
fi

mkdir -p /usr/ports/mineos/libconfig
cd /usr/ports/mineos/libconfig
wget http://minecraft.codeemo.com/crux/mineos-scripts/addons/Pkgfile-libconfig -O Pkgfile
pkgmk -d -i

mkdir -p /usr/ports/mineos/protobuf
cd /usr/ports/mineos/protobuf
wget http://minecraft.codeemo.com/crux/mineos-scripts/addons/Pkgfile-protobuf -O Pkgfile
pkgmk -d -i

mkdir -p /usr/ports/mineos/protobuf-c
cd /usr/ports/mineos/protobuf-c
wget http://minecraft.codeemo.com/crux/mineos-scripts/addons/Pkgfile-protobuf-c -O Pkgfile
pkgmk -d -i

mkdir -p /usr/ports/mineos/umurmur
cd /usr/ports/mineos/umurmur
wget http://minecraft.codeemo.com/crux/mineos-scripts/addons/Pkgfile-umurmur -O Pkgfile
pkgmk -d -i

mkdir -p /etc/umurmur
cd /etc/umurmur
wget http://minecraft.codeemo.com/crux/mineos-scripts/addons/umurmur.conf

cd /etc/rc.d
wget http://minecraft.codeemo.com/crux/mineos-scripts/addons/umurmurd
chmod +x umurmurd

groupadd umurmur
useradd -M -g umurmur -s /sbin/nologin umurmur
