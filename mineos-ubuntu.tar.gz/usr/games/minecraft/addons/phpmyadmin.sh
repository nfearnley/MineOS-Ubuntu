#!/bin/bash

if [ "$(id -u)" != "0" ]; then
        echo "This script must be run as root" 1>&2
        exit 1
fi

mkdir -p /usr/ports/mineos/phpmyadmin
cd /usr/ports/mineos/phpmyadmin
wget http://minecraft.codeemo.com/crux/mineos-scripts/addons/Pkgfile-phpmyadmin -O Pkgfile
pkgmk -d -i
chown -R mc:games /var/www/phpmyadmin
chown -R mc:games /var/www/upload
chmod -R 700 /var/www/upload

