echo Enter password for user mc:
# set password for mc
which passwd
passwd mc

echo Enter password for website:
# setup web password
htpasswd -c /var/www/.htpasswd mc