#!/bin/sh

cd /usr/games/minecraft
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/server.py
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/mineos.py
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/mineos_console.py
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/mineos.config

mkdir /usr/games/minecraft/addons
cd /usr/games/minecraft/addons
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/addons/umurmur.sh
chmod +x umurmur.sh
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/addons/pigmap.sh
chmod +x pigmap.sh
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/addons/phpmyadmin.sh
chmod +x phpmyadmin.sh
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/addons/mysql_create_user.py
chmod +x mysql_create_user.py

cd /var/www/admin
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/index.html

cd /var/www/admin/css
wget -N http://minecraft.codeemo.com/crux/mineos-scripts/css/stylin.css
