
# Make sure only root can run our script
if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

echo --- Installing LAMP server ---
# install lamp-server
apt-get install lamp-server^

echo --- Installing Java ---
apt-get install openjdk-6-jre-headless

echo --- Adding user mc ---
# add user "mc" as member of group "games"
groupadd games
useradd -g games -m mc

echo --- Setting up mc home directories --- 
# setup mc home directories
mkdir -p /home/mc/archive
mkdir -p /home/mc/backup
mkdir -p /home/mc/snapshots
mkdir -p /home/mc/servers
mkdir -p /home/mc/import
chown -R mc:games /home/mc

echo --- Setting up cron files ---
# Setup cron files
cp etc/cron/hourly/mineos.hourly /etc/cron.hourly/mineos.hourly
cp etc/cron/daily/mineos.daily /etc/cron.daily/mineos.daily
cp etc/cron/weekly/mineos.weekly /etc/cron.weekly/mineos.weekly
cp etc/cron/monthly/mineos.monthly /etc/cron.monthly/mineos.monthly

echo --- Setting up minecraft service ---
# Setup minecraft service
cp etc/rc.d/minecraft /etc/init.d/minecraft
ln -s /etc/init.d/minecraft /etc/rc2.d/minecraft

echo --- Setting up mc sudoers file ---
# Setup mc sudoers file
cp etc/sudoers.d/mc /etc/sudoers.d/mc
chmod 0440 /etc/sudoers.d/mc
echo \#includedir /etc/sudoers.d >> /etc/sudoers

# echo Setting up runonce files
# setup runonce files
# mkdir -p /home/ubuntu/runonce
# cp root/runonce/setup_mineos /home/ubuntu/runonce/setup_mineos
# cp root/runonce/webui /home/ubuntu/runonce/webui

echo --- Setting up minecraft directory ---
# setup minecraft directory
mkdir -p /usr/games/minecraft
mkdir -p /usr/games/minecraft/addons
cp usr/games/minecraft/mineos.config /usr/games/minecraft/mineos.config
cp usr/games/minecraft/mineos_console.py /usr/games/minecraft/mineos_console.py
cp usr/games/minecraft/mineos.py /usr/games/minecraft/mineos.py
cp usr/games/minecraft/server.py /usr/games/minecraft/server.py
chmod u+x /usr/games/minecraft/mineos_console.py
chmod u+x /usr/games/minecraft/mineos.py
chmod u+x /usr/games/minecraft/server.py
cp usr/games/minecraft/addons/phpmyadmin.sh /usr/games/minecraft/addons/phpmyadmin.sh
cp usr/games/minecraft/addons/pigmap.sh /usr/games/minecraft/addons/pigmap.sh
cp usr/games/minecraft/addons/umurmur.sh /usr/games/minecraft/addons/umurmur.sh
chmod u+x /usr/games/minecraft/addons/phpmyadmin.sh
chmod u+x /usr/games/minecraft/addons/pigmap.sh
chmod u+x /usr/games/minecraft/addons/umurmur.sh
chown -R mc:games /usr/games/minecraft

echo --- Setting up Apache2 server ---
# setup apache2
cp etc/apache2/envvars /etc/apache2/envvars
cp etc/apache2/sites-available/mc /etc/apache2/sites-available/mc
a2dissite default
a2ensite mc
service apache2 restart

echo --- Setting up www directory ---
# setup /var/www
mkdir -p /var/www/admin
mkdir -p /var/www/admin/cgi-bin
mkdir -p /var/www/admin/css
mkdir -p /var/www/admin/images
mkdir -p /var/www/admin/js
rm /var/www/index.html
cp var/www/hiawatha/admin/index.html /var/www/admin/index.html
cp var/www/hiawatha/admin/css/stylin.css /var/www/admin/css/stylin.css
cp var/www/hiawatha/admin/images/logo.jpg /var/www/admin/images/logo.jpg
cp var/www/hiawatha/admin/js/jquery-1.6.2.js /var/www/admin/js/jquery-1.6.2.js
ln -s /usr/games/minecraft/mineos.config /var/www/admin/cgi-bin/mineos.config
ln -s /usr/games/minecraft/mineos_console.py /var/www/admin/cgi-bin/mineos_console.py
ln -s /usr/games/minecraft/mineos.py /var/www/admin/cgi-bin/mineos.py
ln -s /usr/games/minecraft/server.py /var/www/admin/cgi-bin/server.py
ln -s /home/mc/snapshots /var/www/snapshots
chown -R mc:games /var/www

#chown -R root:root /var/www/admin/cgi-bin
#chown mc:games /var/www/admin/cgi-bin


echo --- Setting up password change script ---
cp changepw.sh /home/ubuntu/changepw.sh
rm /etc/update-motd.d/51_update-motd
cp etc/update-motd.d/51-mineos-motd /etc/update-motd.d/51-mineos-motd